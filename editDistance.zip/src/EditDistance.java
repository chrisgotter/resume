/********************************************************************
 *                                                                  *
 * cs&143 - April 2012                                              *
 * Programming Assignment #5 � Edit distance    	    	    *
 * Due Date: 5/2/12 5:00 PM                                         *
 * Deliverables: EditDistance.java, EditDistance.out, 	 	    *
 * 			EditDistance.txt       			    *
 *                                                                  *
 ********************************************************************
 *                                                                  *
 * Author: Christopher Ottersen                                     *
 *                                                                  *
 ********************************************************************
 *                                                                  *
 * Purpose:                                                         *
 *                                                                  *
 * This program is designed to compute the edit distance (also 	    *
 * called the Levenshtein distance, for its creator Vladimir 	    *
 * Levenshtein) between two words. The edit distance between two    *
 * strings is the minimum number of operations that are needed to   *
 * transform one string into the other. In order to add a further   *
 * level of challenge the requirement has been added that the 	    *
 * result of every operation must be a word present in the 	    *
 * dictionary. 							    *
 * For Example:							    *
 * 								    *
 * 		distance from cat to dog is 3 because 	  	    *
 * 		[cat, cot, cog, dog] consists of 3 operations, 	    *
 * 		and it is the shortest path between the two words.  *
 * 								    *
 * The first step of the searching algorithm is the method setUp.   *
 * This method takes a LinkedList of HashSets as a parameter, which *
 * is initialized with the first and last words stipulated by the   *
 * user and checks to see if they have common elements. If 	    *
 * there is a common element then the list is returned, if not the  *
 * an element is added between those analyzed containing all 	    *
 * possible moves from all set elements in the list element with    *
 * the lower index value. The element ordering is then reversed     *
 * and, and the method is called again. This cycle continues 	    *
 * until the two most recently created list elements are found to   *
 * have common set elements or it is determined that no match will  *
 * be made. The above processes are illustrated below.		    *
 * 								    *
 * 	node1 					node2		    *
 *	a					    b		    *
 *	node1 node2 				node3		    *
 *	b-    b1b2				    a		    *
 *	node1 node2 			  node3	node4		    *
 *	a-    a1a2		  	   b1b2    -b		    *
 *	node1 node2 node3 	 	  node4	node5		    *
 *	b-    b1b2- b11b12b21b22	   a1a2    -a		    *
 *								    *
 * If a common element is found then one of the two elements who's  *
 * comparison found it is destroyed and all elements other than     *
 * the commonality are removed from the other set. The list is then *
 * passed on to the findList method. The findList method finds the  *
 * first common element between the possible moves from the node in *
 * question and the set in the node immediately above it and 	    *
 * replaces the next node with that value until the end of the list *
 * is reached. Then the list is reversed and the process is 	    *
 * repeated. After its second execution the list consists of a	    *
 * LinkedList of HashSets (each of which comprised of a single 	    *
 * word). Small modifications are made to ensure that the list is   *
 * in the right order and easier to deal with. Finally the list and *
 * its size are displayed for the user. This program was written in *
 * Java 1.6.                                                        *
 *                                                                  *
 ********************************************************************
 *                                                                  *
 * Inputs: two words of equal size present in the attached 	    *
 * 		dictionary. possibly an address for the dictionary. *
 * Outputs: instructions, optimum path (list of strings), distance. *
 * 			"no Solution".				    *
 * Errors Reported: 						    *
 *			if(word is not present in dictionary){	    *
 *				does not appear to be a word	    *
 *				Edit distance can only be computed  *
 *				between *words* of equal length.    *
 *			}					    *
 *			if(word length is not consistent){	    *
 *				Edit distance can only be computed  *
 *				between words of equivalent length. *
 *			}					    *
 *			if(default dictionary address is not valid){*
 *				apparently my dictionary address    *
 *				is not valid on your computer, 	    *
 *				please enter the correct one: 	    *
 *			}					    *
 *                                                                  *
 ********************************************************************/
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class EditDistance {

    private static LinkedList<HashSet<String>> sortedWords = new LinkedList<HashSet<String>>();
    private static HashMap<String, HashSet<String>> connections = new HashMap<String, HashSet<String>>();


    /******************************************************************* * *
    * 									   *
    * 	main()                                                             *
    *  									   *
    * 	test harness method for this class. This method calls the	   *
    * 	interaction method.  						   *
    * 									   *
    * * ********************************************************************/
    public static void main(String[] args) throws FileNotFoundException{
    	interaction();

    }


    /******************************************************************* * *
    * 									   *
    * 	interaction()                                                      *
    *  									   *
    * 	provides the user interface for this program. Prompts the user for *
    * 	parameters then, after testing user inputs for validity, uses the  *
    * 	parameters to call the callSearch() method and displays the proper *
    * 	output based on that method's output.				   *
    * 									   *
    * * ********************************************************************/
    public static void interaction() throws FileNotFoundException{
    	//primes the program for user input
    	Scanner input = new Scanner(System.in);
    	//imports dictionary file
    	populateDictionary();
    	//initializes start and finish
    	String start = "";
    	String finish = "";
    	//prints first half of first iteration
    	System.out.println("Lets find an edit distance between words.");
    	//recieves first word
    	System.out.print("\tfirst word (enter to quit)? ");
    	start = input.nextLine();

    	//continues while user stipulates a start value
    	while(start.length() > 0){

        	//recieves second word
    		System.out.print("\tsecond word? ");
    		finish = input.nextLine();

    		//analyzes words if they are acceptable
    		if(checkInput(start, finish)){
    			//finds list
    			LinkedList<String> search = callSearch(start, finish);
    			Iterator<String> itr = search.iterator();

    			//displays list
    			while(itr.hasNext()){
        			System.out.print(itr.next());
        			if(itr.hasNext()){
        				System.out.print(", ");
        			}
        		}

        		//displays distance
        		if(!search.contains("no solution")){
        			System.out.println("\nEdit distance = " + (search.size() - 1));
        		}
    		}


    		//begin prompt for nexxt input
    		System.out.println("Lets find an edit distance between words.");
        	System.out.print("\tfirst word (enter to quit)? ");
        	start = input.nextLine();
    	}
    }

    /******************************************************************* * *
    * 									   *
    * 	checkInput(String start, String finish)                            *
    *  									   *
    * 	tests user parameter input to determine whether or not the	   *
    * 	parameters are suitable for calling further methods.		   *
    * 									   *
    * * ********************************************************************/
    public static boolean checkInput(String start, String finish){
    	boolean pass = true;
    	//verifies that there are actually words of this length within the sortedWords list
    	if(sortedWords.get(start.length()) != null && sortedWords.get(finish.length()) != null){
    		//verifies that each word is actually in sortedWords
    		if(!sortedWords.get(start.length()).contains(start)){
        		System.out.println(start + " does not appear to be a word\nEdit distance can only be computed \nbetween *words* of equal length\n");
        		pass = false;
        	}

        	if(!sortedWords.get(finish.length()).contains(finish)){
        		System.out.println(finish + " does not appear to be a word\nEdit distance can only be computed \nbetween *words* of equal length\n");
        		pass = false;
        	}
    	}
    	else{
    		System.out.println("at least one of these words \ndoes not appear to be a \nEdit distance can only be computed \nbetween *words* of equal length\n");
    		pass = false;
    	}

    	//verifies that words are same length
    	if(start.length() != finish.length()){
    		System.out.println("Edit distance can only be computed \nbetween words of equivalent length\n");
    		pass = false;
    	}

    	if(!pass){
    		System.out.println("Please try again.");
    	}

    	return pass;
    }

    /******************************************************************* * *
    * 									   *
    * 	testDictionaryAddress(String address)	                           *
    *  									   *
    * 	tests the programmer defined default dictionary address to verify. *
    * 	that it is still valid. If the address is not valid then it 	   *
    * 	prompts the user for a new one.					   *
    * 									   *
    * * ********************************************************************/
    public static Scanner testDictionaryAddress(String address){
    	Scanner input = null;
    	//trys the file address provided
    	try{
        	input = new Scanner(new File(address));
        }
        catch(FileNotFoundException ex){
        	//allows the user to provide a new address if the given one is not valid
        	System.out.print("apparently my dictionary address \nis not valid on your computer, \nplease enter the correct one: ");
        	Scanner keyboard = new Scanner(System.in);
        	address = keyboard.nextLine();
        	System.out.println();
        	//checks new address
        	input = testDictionaryAddress(address);
        }
        //returns scanner with first valid input
    	return input;
    }

    /******************************************************************* * *
    * 									   *
    * 	populateDictionary()					           *
    *  									   *
    * 	populates the dictionary LinkedList with words having lengths 	   *
    * 	corresponding to the indexes of the LinkedList.			   *
    * 									   *
    * * ********************************************************************/
    public static LinkedList<HashSet<String>> populateDictionary() throws FileNotFoundException{
    	HashMap<Integer, HashSet<String>> dictionary = new HashMap<Integer, HashSet<String>>();

    	//verifies that the dictionary address provided
    	//by the programmer is valid
    	Scanner input = testDictionaryAddress("dictionary.txt");

    	//parses through the dictionary document and adds all words to
    	//map locations with keys being the word length.
        while(input.hasNext()){
            String newWord = input.nextLine();
            //creates new map element if this is the first word of its size
            if(dictionary.containsKey(newWord.length())){
            	dictionary.get(newWord.length()).add(newWord);
            }
            //adds new word to map element of proper size
            else{
            	HashSet<String> temp = new HashSet<String>();
            	temp.add(newWord);
            	dictionary.put(newWord.length(), temp);

            }

        }
        Iterator<Integer> dict = dictionary.keySet().iterator();
        int largestWord = 0;
        //finds the longest word in dictionary
        while(dict.hasNext()){
        	largestWord = dict.next();
        }

        //places all words in dictionary into the public LinkedList
        //sameSize words for ease of use purposes
        for(int i = 0; i <= largestWord; i++){
        	if(dictionary.containsKey(i)){
        		sortedWords.add(dictionary.get(i));
        	}
        	else{
        		sortedWords.add(null);
        	}
        }
        return sortedWords;

    }

    /******************************************************************* * *
    * 									   *
    * 	connections(String start)				           *
    *  									   *
    * 	adds a HashSet element to the connections map corresponding with   *
    * 	the start parameter being its key, and a HashSet of all words 	   *
    * 	differing from it by one letter being the element.		   *
    * 									   *
    * * ********************************************************************/
    public static HashSet<String> connections(String start){
    	//ensures that key word actually exists
    	if(!sortedWords.get(start.length()).contains(start)){
    		return null;
    	}

        Iterator<String> itr1 = sortedWords.get(start.length()).iterator();
        HashSet<String> set = new HashSet<String>();

        //searches all same size words
        while(itr1.hasNext()){

            String possibleMove = itr1.next();
            int correlation = 0;
            //counts the number of numerical differences between each word
            //and the parameter
            for(int i = 0; i < possibleMove.length(); i++){
                if(possibleMove.charAt(i) != start.charAt(i)){
                    correlation++;
                }

            }

            //places all words with exactly one difference in one set
            if(correlation == 1){
                set.add(possibleMove);
            }

        }
        //adds that set to connections with start as its key
        connections.put(start, set);
        return set;

    }

    /******************************************************************* * *
    * 									   *
    * 	callSearch(String start, String finish)	                           *
    *  									   *
    * 	this is the outermost level of the displacement path calculation.  *
    * 	This method initializes the path LinkedList. Calls the setUp 	   *
    * 	method, finalizes the list with the callFindList method, and	   *
    * 	finally cleans up the list a bit and returns it.		   *
    * 									   *
    * * ********************************************************************/
    public static LinkedList<String> callSearch(String start, String finish){

    	//initialize path
    	LinkedList<HashSet<String>> path = new LinkedList<HashSet<String>>();

    	//initialize first and last path elements
    	HashSet<String> begin = new HashSet<String>();
    	HashSet<String> end = new HashSet<String>();

    	begin.add(start);
    	end.add(finish);

    	//add first and last elements to path
    	path.add(begin);
    	path.addLast(end);

    	//calls setUp to find the uncleaned list
    	path = setUp(start, -1, path);

    	//cleans up list with callFindList
    	if(path.size() > 1){
    		path = callFindList(path, true);
    	}

    	LinkedList<String> solution = new LinkedList<String>();

		//ensures that path is in the correct order
    	//and places it in a LinkedList<String> for
    	//easier use
		for(int i = 0; i < path.size(); i++){
    		Iterator<String> pth = path.get(i).iterator();
    		if(path.size() % 2 == 1){
    			solution.add(0, pth.next());
        	}
    		else{
    			solution.add(pth.next());
    		}
    	}

    	return solution;

    }

    /******************************************************************* * *
    * 									   *
    * 	containsAny(HashSet<String> container, HashSet<String> content)    *
    *  									   *
    * 	this method is a variation of the retainAll() method. It serves    *
    * 	several purposes throughout the class. This method returns either  *
    * 	one element which the two parameter lists have in common or if 	   *
    * 	they have none in common it returns null.			   *
    * 									   *
    * * ********************************************************************/
    public static HashSet<String> containsAny(HashSet<String> container, HashSet<String> content){
    	Iterator<String> itr = content.iterator();
    	HashSet<String> temp = new HashSet<String>();

    	//searches all elements in content
    	while(itr.hasNext()){
    		String element = itr.next();

    		//compares checks container for elements
    		if(container.contains(element)){

    			temp.add(element);
    			//returns first commonality
    			return temp;
    		}
    	}
    	//returns null if no commonality is found
    	return null;


    }

    /******************************************************************* * *
    * 									   *
    * 	containsAny(HashSet<String> container, HashSet<String> content)    *
    *  									   *
    * 	this method is a variation of the retainAll() method. It serves    *
    * 	several purposes throughout the class. This method returns either  *
    * 	one element which the two parameter lists have in common or if 	   *
    * 	they have none in common it returns null.			   *
    * 									   *
    * * ********************************************************************/
    public static LinkedList<HashSet<String>> callFindList(LinkedList<HashSet<String>> path, boolean firstExicution){
		int midPoint = 0;
		for(int i = 1; i < path.size() - 1; i++){
			//saves the midpoint
			if(path.get(i).size() == 1){
				midPoint = i;
			}
		}
		//calls findList with calculated midPoint
		path = findList(midPoint, path, firstExicution);

    	return path;

    }

    /******************************************************************* * *
    * 									   *
    * 	findList(int startLocation, LinkedList<HashSet<String>> path, 	   *
    * 					boolean firstExicution)   	   *
    *  									   *
    * 	this method reduces the size of each HashSet, in the path 	   *
    * 	LinkedList provided by setUp, to 1. This is accomplished by 	   *
    * 	replacing the value of each element in path with the output of 	   *
    * 	containsAny(element - 1, element) starting with the midpoint and   *
    * 	radiating toward the end. Then flips path around and calls 	   *
    * 	callFindList() again to execute the same operation between the 	   *
    * 	beginning and the middle.					   *
    * 									   *
    * * ********************************************************************/
    public static LinkedList<HashSet<String>> findList(int startLocation, LinkedList<HashSet<String>> path, boolean firstExicution){
    	Iterator<String> itr = path.get(startLocation).iterator();
    	HashSet<String> nextTier = new HashSet<String>();
    	//finds the list of connections for comparison
    	while(itr.hasNext()){
    		String possibleMove = itr.next();
    		if(!connections.containsKey(possibleMove)){
        		connections(possibleMove);
        	}
    		nextTier.addAll(connections.get(possibleMove));

    	}

    	//shrinks the next element and moves on
    	if(path.get(startLocation + 1).size() > 1){
    		path.set(startLocation + 1, containsAny(path.get(startLocation + 1), nextTier));
    		findList(startLocation + 1, path, firstExicution);
    	}

    	//flips the list and calls the method one more time
    	//to clean up the other half of the list
    	else if(firstExicution){
    		for(int i = path.size() -1; i >= 0; i--){
        		path.addLast(path.remove(i));
        	}
    		callFindList(path, false);
    	}
    	return path;

    }

    /******************************************************************* * *
    * 									   *
    * 	setUp(String start, int tier, LinkedList<HashSet<String>> path)	   *
    * 									   *
    * 	This method takes a LinkedList of HashSets as a parameter, which   *
    * 	is initialized with the first and last words stipulated by the 	   *
    * 	user and checks to see if they have common elements. If 	   *
    * 	there is a common element then the list is returned, if not the    *
    * 	an element is added between those analyzed containing all 	   *
    * 	possible moves from all set elements in the list element with 	   *
    * 	the lower index value. The element ordering is then reversed 	   *
    * 	and, and the method is called again. This cycle continues 	   *
    * 	until the two most recently created list elements are found to 	   *
    * 	have common set elements or it is determined that no match will    *
    * 	be made. The above processes are illustrated below.		   *
    * 									   *
    * 	node1 					node2		 	   *
    *	a					    b		    	   *
    *	node1 node2 				node3		    	   *
    *	b-    b1b2				    a		     	   *
    *	node1 node2 			  node3	node4		    	   *
    *	a-    a1a2		  	   b1b2    -b		    	   *
    * 	node1 node2 node3 	 	  node4	node5		    	   *
    *	b-    b1b2- b11b12b21b22	   a1a2    -a		    	   *
    *								  	   *
    * 	If a common element is found then one of the two elements who's    *
    * 	comparison found it is destroyed and all elements other than 	   *
    * 	the commonality are removed from the other set. The list is then   *
    * 	passed on to the findList method.				   *
    * 									   *
    * * ********************************************************************/
    public static LinkedList<HashSet<String>> setUp(String start, int tier, LinkedList<HashSet<String>> path){
    	tier++;

    	//checks for commonalities between sets
    	if(containsAny(path.get((tier/2)), path.get((tier/2) + 1)) != null){
			//System.out.println(path.size());
			path.set((tier/2) + 1, containsAny(path.get((tier/2)), path.get((tier/2) + 1)));
			path.remove((tier/2));

			return path;
		}

    	//fills the tier
    	Iterator<String> itr = path.get((tier/2)).iterator();
    	HashSet<String> nextTier = new HashSet<String>();
    	while(itr.hasNext()){
    		String possibleMove = itr.next();
    		if(!connections.containsKey(possibleMove)){
        		connections(possibleMove);
        	}
    		if(connections.get(possibleMove) != null){
    			nextTier.addAll(connections.get(possibleMove));
    		}

    	}


    	//determines if no solution is possible
    	path.add((tier/2) + 1, nextTier);
    	if(nextTier.size() == 0){
    		path.clear();
    		HashSet<String> temporary = new HashSet<String>();
    		temporary.add("no solution");
    		path.add(temporary);
    		return path;
    	}

    	//cleans items present at earlier levels of the list out of later sets
    	//it ensures that at some point the sets will start growing
    	//smaller and in the event that no translation between words
    	//is possible it ensures that at some point the new sets will
    	//be empty.
//    	if((tier/2) - 2 <= 0){
//    		path.get((tier/2)).removeAll(path.get((tier/2) - 2));
//    	}
    	for(int i = 0; i < (tier/2) + 1; i++){
    		path.get((tier/2) + 1).removeAll(path.get(i));
    	}

    	//reverses the list
    	for(int i = path.size() -1; i >= 0; i--){
    		path.addLast(path.remove(i));
    	}

    	//recursively recalls the method
    	setUp(start, tier, path);

        return path;

    }
}